﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6212POEClassLibrary
{
    public class Calculation
    {
        public double selfHours(double a, double b, double c)
        {
            // Calculation given in POE
            return ((a * 10)/b) - c;
        }

        public double selfHoursRemain(double a)
        {
            DateTime currentDate = DateTime.Today;

            // Calculate the current day of the week
            int currentDayOfWeek = (int)currentDate.DayOfWeek;

            // Calculate the number of days until the end of the week
            int daysUntilEndOfWeek = 7 - currentDayOfWeek;

            // Calculate how many hours a day
            double dailyHours = a / 7;


            return dailyHours * daysUntilEndOfWeek;
        }
    }

    public class Modules
    {
        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public double numOfCredits { get; set; }
        public double classHoursPerWeek { get; set; }
        public double selfStudy { get; set; }
        public double selfStudyRemain { get; set; }

        
    }
    public class Semester
    {
        public int NumberOfWeeks { get; set; }
        public DateTime StartDate { get; set; }
    }
    
}
