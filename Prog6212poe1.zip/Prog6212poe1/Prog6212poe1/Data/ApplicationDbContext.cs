﻿using Microsoft.EntityFrameworkCore;
using Prog6212poe1.Models;
using System.Collections.Generic;

namespace Prog6212poe1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<ModuleModel> Modules { get; set; }
        public DbSet<HoursWorkedModel> HoursWorked { get; set; }

    }

    
}
