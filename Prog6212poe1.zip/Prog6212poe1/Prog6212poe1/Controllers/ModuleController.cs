﻿using Microsoft.AspNetCore.Mvc;
using Prog6212poe1.Models;
using Prog6212poe1.Services;

namespace Prog6212poe1.Controllers
{
    public class ModuleController : Controller
    {
        private readonly UserService _userService;
        private readonly ModuleService _moduleService;

        public ModuleController(UserService userService, ModuleService moduleService)
        {
            _userService = userService;
            _moduleService = moduleService;
        }


        [HttpGet]
        public IActionResult Create()
        {
            // Display the form to create a new module
            int userId = HttpContext.Session.GetInt32("UserId") ?? -1;


            if (userId != -1)
            {
                ViewData["UserId"] = userId;
                var viewModel = new CreateViewModel
                {
                    Module = new ModuleModel(),
                    HoursWorked = new HoursWorkedModel()
                };

                return View(viewModel);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
            // Retrieve modules for the user 
        }

        [HttpPost]
        public IActionResult Create(CreateViewModel viewModel)
        {
            // Retrieve user ID from session
            int userId = HttpContext.Session.GetInt32("UserId") ?? -1;

            if (userId != -1)
            {

                // Save the module to the database
                _moduleService.SaveModuleToDatabase(viewModel.Module, userId);
                // Don't redirect here; let the user decide when to go to MyModules
                // return RedirectToAction("MyModules");
                ModelState.Clear();
            }
            else
            {
                // Handle the case where the user is not logged in
                return RedirectToAction("Login", "Auth");
            }

            // You can choose to return a different view or perform other actions here
            return View();
        }

        [HttpGet]
        public IActionResult MyModules()
        {
            // Retrieve user ID from session
            int userId = HttpContext.Session.GetInt32("UserId") ?? -1;

            if (userId != -1)
            {
                var userModules = _moduleService.GetModulesByUserId(userId);

                // Retrieve hours worked for the current user
                var hoursWorked = _moduleService.GetHoursWorkedByUserId(userId);

                // Create a ViewModel to pass to the view
                var viewModel = new MyModulesViewModel
                {
                    UserModules = userModules,
                    HoursWorked = hoursWorked
                };

                return View(viewModel);
            }
            else
            {
                // Handle the case where the user is not logged in
                return RedirectToAction("Login", "Auth");
            }
        }

        [HttpPost]
        public IActionResult AddHoursWorked(CreateViewModel viewModel)
        {
            int userId = HttpContext.Session.GetInt32("UserId") ?? -1;

            if (userId != -1)
            {
                // Set the UserId property
                viewModel.HoursWorked.userID = userId;

                // Add hours worked to the database
                _moduleService.AddHoursWorkedToDatabase(viewModel.HoursWorked);

                // You can add any additional logic or redirection here
            }

            return RedirectToAction("Create");
        }
        [HttpPost]
        public IActionResult Login()
        {
            // Sign out the user and remove the session
            HttpContext.Session.Clear();

            // Redirect to the login page or any other desired page after logging out
            return RedirectToAction("Login", "Auth");
        }
    }
}
