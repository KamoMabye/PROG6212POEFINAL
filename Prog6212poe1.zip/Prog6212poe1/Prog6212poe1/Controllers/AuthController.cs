﻿using Microsoft.AspNetCore.Mvc;
using Prog6212poe1.Models;
using Prog6212poe1.Services;
using Prog6212poe1.Data;

namespace Prog6212poe1.Controllers
{
    public class AuthController : Controller
    {
        private readonly UserService _userService;

        public AuthController(UserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserModel user)
        {
            

            var newUser = new User
            {
                Username = user.Username,
                Password = user.Password,
            };
            
            _userService.AddUser(newUser);

            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserModel user)
        {
            var authenticatedUser = _userService.GetUserByUsernameAndPassword(user.Username, user.Password);

            if (authenticatedUser != null)
            {
                // Authentication successful, store user ID in session
                HttpContext.Session.SetInt32("UserId", authenticatedUser.UserId);

                return RedirectToAction("MyModules", "Module");
            }

            // Authentication failed, return to the login page
            ModelState.AddModelError(string.Empty, "Invalid username or password.");
            return View();
        }

    }


}
