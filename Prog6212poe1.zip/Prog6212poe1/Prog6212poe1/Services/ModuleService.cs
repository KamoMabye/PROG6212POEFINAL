﻿using Prog6212poe1.Data;
using Prog6212poe1.Models;

namespace Prog6212poe1.Services
{
    public class ModuleService
    {
        private readonly ApplicationDbContext _dbContext;

        public ModuleService(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void SaveModuleToDatabase(ModuleModel module, int userId)
        {
            try
            {
                // Set the CreatedAt property to the current date/time
                //module.CreatedAt = DateTime.UtcNow;
                module.SelfStudyHours = CalculateSelfStudyHours(module.Credits, module.ClassHours, module.Weeks);
                module.selfStudyRemain = selfHoursRemain(module.SelfStudyHours);
                module.UserId = userId;
                module.PlannedDayOfWeek = module.PlannedDayOfWeek;
                // Add the module to the Modules DbSet
                _dbContext.Modules.Add(module);

                // Save changes to the database
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle the exception according to your application's error-handling strategy
                Console.WriteLine($"Error saving module to the database: {ex.Message}");
                // You might want to throw or log the exception, or take other appropriate actions
                throw;
            }
        }
        private double CalculateSelfStudyHours(double credits, double classHours, int weeks)
        {
            // Calculate selfStudyHours using the specified formula
            return (credits * 10 / weeks) - classHours;
        }

        private double selfHoursRemain(double a)
        {
            DateTime currentDate = DateTime.Today;

            // Calculate the current day of the week
            int currentDayOfWeek = (int)currentDate.DayOfWeek;

            // Calculate the number of days until the end of the week
            int daysUntilEndOfWeek = 7 - currentDayOfWeek;

            // Calculate how many hours a day
            double dailyHours = a / 7;


            return dailyHours * daysUntilEndOfWeek;
        }

        public IEnumerable<ModuleModel> GetModulesByUserId(int userId)
        {
            return _dbContext.Modules
                .Where(m => m.UserId == userId)
                .ToList();
        }
        public void AddHoursWorkedToDatabase(HoursWorkedModel hoursWorked)
        {
            try
            {
                _dbContext.HoursWorked.Add(hoursWorked);
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle the exception
                Console.WriteLine($"Error adding hours worked to the database: {ex.Message}");
                throw;
            }
        }

        public IEnumerable<HoursWorkedModel> GetHoursWorkedByUserId(int userId)
        {
            return _dbContext.HoursWorked
                .Where(hw => hw.userID == userId)
                .ToList();
        }


    }
}
