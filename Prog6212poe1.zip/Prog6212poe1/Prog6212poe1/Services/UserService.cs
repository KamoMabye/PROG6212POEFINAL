﻿using Prog6212poe1.Data;
using Prog6212poe1.Models;
using System;
using System.Linq;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;

namespace Prog6212poe1.Services
{

    public class UserService
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserService(ApplicationDbContext dbContext, IHttpContextAccessor httpContextAccessor)
        {
            _dbContext = dbContext;
            _httpContextAccessor = httpContextAccessor;

        }

        public void AddUser(User user)
        {
            // Hash the password before storing it in the database
            user.Password = user.Password;

            _dbContext.Users.Add(user);
            _dbContext.SaveChanges();
        }

        public User GetUserByUsernameAndPassword(string username, string password)
        {
            // Retrieve the user by username and password
            var user = _dbContext.Users
                .FirstOrDefault(u => u.Username == username && u.Password == password);

            return user;
        }

    }


}
