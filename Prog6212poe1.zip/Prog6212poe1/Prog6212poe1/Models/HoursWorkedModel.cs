﻿namespace Prog6212poe1.Models
{
    public class HoursWorkedModel
    {
        public int ID { get; set; }
        public string ModuleName { get; set; }
        public double hoursWorked { get; set; }
        public DateTime DateWorked { get; set; }
        public int userID { get; set; }
    }

}
