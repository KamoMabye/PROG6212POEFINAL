﻿namespace Prog6212poe1.Models
{
    public class CreateViewModel
    {
        public ModuleModel Module { get; set; }
        public HoursWorkedModel HoursWorked { get; set; }
    }

}
