﻿using System.ComponentModel.DataAnnotations;

namespace Prog6212poe1.Models
{
    public class ModuleModel
    {
        [Key]
        public int ModuleId { get; set; }

        public int UserId { get; set; }
        public string ModuleCode { get; set; }
        public string ModuleName { get; set; }
        public int Credits { get; set; }
        public int ClassHours { get; set; }
        public double SelfStudyHours { get; set; }

        public double selfStudyRemain { get; set;}
        public int Weeks { get; set; }

        [Display(Name = "Planned Day of Week")]
        public DayOfWeek PlannedDayOfWeek { get; set; }

    }

}
