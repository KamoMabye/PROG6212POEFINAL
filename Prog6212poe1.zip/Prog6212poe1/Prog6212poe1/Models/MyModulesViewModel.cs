﻿namespace Prog6212poe1.Models
{
    public class MyModulesViewModel
    {
    public IEnumerable<ModuleModel> UserModules { get; set; }
    public IEnumerable<HoursWorkedModel> HoursWorked { get; set; }
    }

}
